local isShowing = false
local lastUpdate = 0

exports('showHelpNotification', function(msg)
    lastUpdate = GetGameTimer()

    if not isShowing then
        SendNUIMessage({
            action = 'show',
            text = msg
        })
        isShowing = true
    else
        SendNUIMessage({
            action = 'update',
            text = msg
        })
    end
end)

Citizen.CreateThread(function()
    while true do
        local sleep = 500
        local currentTime = GetGameTimer()

        if isShowing then
            if (currentTime - lastUpdate > 1000) or IsPauseMenuActive() then
                SendNUIMessage({ action = 'hide' })
                isShowing = false
            else
                if not IsHudComponentActive(10) then
                end
            end
            sleep = 200
        end
        
        Citizen.Wait(sleep)
    end
end)